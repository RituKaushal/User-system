<?php
$user_system = new User_System();
?>
<div class="main-section">
	<span class="empty" style="display:none;color:red;font-size:15px;text-align:center;">Please Choose the file.</span>
	<span class="success" style="display:none;color:green;font-size:15px;text-align:center;">Users Data is Imported Successfully.</span>
	<span class="not_success" style="display:none;color:red;font-size:15px;text-align:center;">Users Data is Not Imported Successfully.</span>
	<div class="container">
		<input type="hidden" id="site_url" value="<?php echo SITE_URL; ?>">
		<form method="post" enctype="multipart/form-data" id="user_system">
			Select File to upload:
			  <input type="file" name="fileToUpload" id="fileToUpload" accept=".csv" required>
			  <input type="submit" value="Import" name="import" id="user_import">
			  <input type="submit" value="Export" name="export" id="user_export">
		</form>
	</div>
</div>