jQuery(document).ready(function(){
	jQuery('#user_import').on('click',function(event){
		event.preventDefault();
		var url_data = jQuery('#site_url').val(); 
		var form_data = new FormData();
		var file_data = jQuery('#fileToUpload').prop('files')[0];
		form_data.append('file', file_data);
        form_data.append('action', 'import_users_data');
        var url = url_data + "Controllers/ajaxcontrollers.php";
        jQuery.ajax({
            type: 'post',
            url: url,
          	data: form_data,
            contentType: false,
            processData: false,
            success: function (response) {
            	jQuery('#user_system')[0].reset();
        		var data = jQuery.parseJSON(response);
        		if(data.success == 301){
        			jQuery('.empty').css('display','block');
        			setTimeout(function () {
                     jQuery('.empty').css('display','none');
                 	}, 2500);
        		}
        		else if(data.success == 200){
        			jQuery('.success').css('display','block');
        			setTimeout(function () {
                     jQuery('.success').css('display','none');
                 	}, 2500);
        		}
        		else if(data.success == 404){
        			jQuery('.not_success').css('display','block');
        			setTimeout(function () {
                     jQuery('.not_success').css('display','none');
                 	}, 2500);
        		}
            },  
            error: function (response) {
             console.log('error');
            }

        });
		return false;
	});
});