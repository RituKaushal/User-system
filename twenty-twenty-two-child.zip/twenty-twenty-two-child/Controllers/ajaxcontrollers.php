<?php
$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] ); 
require_once( $parse_uri[0] . 'wp-load.php' );
require_once( $parse_uri[0] . 'wp-content/themes/twenty-twenty-two-child/Models/UserModels.php' );

if(!empty($_POST) && $_POST["action"] == 'import_users_data'){

	if(empty($_FILES['file'])){
		echo json_encode(array('success' =>301, 'result' => 0));
		die;
	}
	else{
		$respones;
		$file_name = !empty($_FILES['file']['name']) ? $_FILES['file']['name'] : "";
		$file_tmp_name = !empty($_FILES['file']['tmp_name']) ? $_FILES['file']['tmp_name'] : "";
		$user_password = UserGenratePassword();
		
		
		if (($handle = fopen($file_tmp_name, "r")) !== FALSE) {
			while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
				$user_login =  !empty($data[0]) ? $data[0] : "";
				$user_email =  !empty($data[1]) ? $data[1] : "";
				$user_name =  !empty($data[5]) ? $data[5] : "";
				$user_password =  !empty($data[0]) ? $data[0] : "";
				$users_data = array(
				    'user_login' => $user_login,
				    'user_pass' => $user_password,
				    'user_email' => $user_email,
				    'first_name' => $user_name
				  );
				$respones = User_insert_fun($users_data);
			}
			if($respones) {
				echo json_encode(array('success' =>200, 'result' => $respones));
			}
		}
		else{
			echo json_encode(array('success' => 404, 'result' => 'users data is not imported'));
		}
		$respones = json_encode($respones);
		return $respones;

	}
	
}

die;