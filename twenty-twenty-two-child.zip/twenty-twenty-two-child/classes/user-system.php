<?php
define("SITE_URL",'http://localhost:8080/User-System/wp-content/themes/twenty-twenty-two-child/');
class User_System{
	public function __construct(){
		 add_action('init', array($this, 'show_user_system_fun'));
		 add_action('admin_enqueue_scripts', array($this, 'user_system_admin_script_fun'));
	}

	public function show_user_system_fun(){
		include get_theme_file_path( '/views/user-system-layout.php' );
	}
	public function user_system_admin_script_fun(){
		wp_enqueue_script('jquery.min', get_stylesheet_directory_uri().'/public/assets/js/jquery.min.js');
		wp_enqueue_script('custom-js', get_stylesheet_directory_uri().'/public/assets/js/custom.js');
	}
}
$user_system = new User_System();
$user_system->show_user_system_fun();
$user_system->user_system_admin_script_fun();
