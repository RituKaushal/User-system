<?php
//random Generate password
function UserGenratePassword() {
    $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
    $pass = array(); //remember to declare $pass as an array
    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
    for ($i = 0; $i < 8; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    return implode($pass); 
}

function User_Insert_Fun($users_details){
$user_id = wp_insert_user($users_details);
$respones;
	if(!empty($user_id)){
		$respones = 'User is Imported Successfully';
	}
	else{
		$respones = 'User is not Imported Successfully';
	}
	return $respones;
}

